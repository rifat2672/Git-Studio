// Desktop window for Git Studio. Starts the backend (backend/dist/server.js)
// and shows the app from http://localhost:4317. Build first: npm run build (in the root folder).
const { app, BrowserWindow, shell, dialog } = require('electron')
const { spawn } = require('child_process')
const path = require('path')
const fs = require('fs')
const http = require('http')

const PORT = process.env.PORT || 4317
const URL = `http://localhost:${PORT}`
const serverFile = path.join(__dirname, '..', 'backend', 'dist', 'server.js')
let backend = null

function ping() {
  return new Promise((resolve) => {
    http.get(`${URL}/api/health`, (res) => { res.resume(); resolve(res.statusCode === 200) }).on('error', () => resolve(false))
  })
}

async function ensureBackend() {
  if (await ping()) return true // already running (e.g. npm start in a terminal)
  if (!fs.existsSync(serverFile)) {
    dialog.showErrorBox('Git Studio', 'The app is not built yet.\n\nIn the git-studio folder run:\n  npm install\n  npm run build')
    return false
  }
  backend = spawn('node', [serverFile], { env: { ...process.env, PORT: String(PORT) }, stdio: 'inherit', windowsHide: true })
  backend.on('error', (e) => dialog.showErrorBox('Git Studio', `Could not start the backend with "node": ${e.message}`))
  for (let i = 0; i < 60; i++) {
    if (await ping()) return true
    await new Promise((r) => setTimeout(r, 250))
  }
  dialog.showErrorBox('Git Studio', 'The backend did not start. Run "npm start" in a terminal to see the error.')
  return false
}

app.whenReady().then(async () => {
  if (!(await ensureBackend())) return app.quit()
  const win = new BrowserWindow({ width: 1440, height: 920, backgroundColor: '#0F1115', title: 'Git Studio', autoHideMenuBar: true })
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith(URL)) return { action: 'allow' }
    shell.openExternal(url)
    return { action: 'deny' }
  })
  win.loadURL(URL)
})

app.on('window-all-closed', () => {
  if (backend) backend.kill()
  app.quit()
})
